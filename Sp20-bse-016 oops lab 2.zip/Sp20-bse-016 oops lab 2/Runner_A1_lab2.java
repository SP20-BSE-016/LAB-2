/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car;

/**
 *
 * @author Cyber World
 */
public class Runner_A1_lab2 {
    public static void main(String[]args){
       Car c1 = new Car();
       Car c2 = new Car();
       c1.model = "Old";
       c1.Num = 0001;
       c1.colour = "blue";
       c2.model = "new";
       c2.Num = 5412;
       c2.colour = "red";
       c1.Traveling();
       c1.Booking();
       c2.Traveling();
       c2.Booking();
       c1.Display();
       c2.Display();
       
    }
    
}
