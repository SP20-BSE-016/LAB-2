/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car;

/**
 *
 * @author Cyber World
 */
public class Runner_A2_lab2 {
     public static void main(String[]args){
        rectangle r1 = new rectangle();
        rectangle r2 = new rectangle();
        r1.sides = 4;
        r1.lenght = 7;
        r1.width = 1;
        r2.sides = 4;
        r2.lenght = 10;
        r2.width = 9;
        r1.Area();
        r1.Cercumfarence();
        r1.Display();
        r2.Area();
        r2.Cercumfarence();
        r2.Display();
    }
    

    
}
