/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car;

/**
 *
 * @author Cyber World
 */
public class rectangle {
    int sides;
    int lenght;
    int width;
   
    public void Cercumfarence(){
        System.out.println("circumfarence of the rectangle is ");
    }
     public void Area(){
        System.out.println("arae of the rectanle is ");
    }
    public void Display(){
        System.out.println("there are  "+sides +"sides of the rectangle "+" with the  length is "+lenght +" and with the width is "+ width);
    }
    

    
}
